using System.Collections.Generic;
using UnityEngine;
using Combat.Perks;

namespace Combat.Weapons
{
    // Top of the weapon hierarchy: the family (Sidearm, Auto Rifle, ...).
    [CreateAssetMenu(fileName = "WeaponType", menuName = "Combat/Weapons/Weapon Type")]
    public class WeaponTypeSO : ScriptableObject
    {
        [Tooltip("Stable id for lookups/saves. Set once, don't rename.")]
        public string id = "";
        [Tooltip("Display name (safe to rename).")]
        public string displayName = "";

        [Header("Loadout")]
        [Tooltip("Slots weapons of this type may be equipped in. A weapon can override this.")]
        public LoadoutSlotMask allowedSlots = LoadoutSlotMask.All;
        [Tooltip("Loadout slot whose carried cap these weapons count against (0 = slot 1). A weapon can override this.")]
        [Range(0, LoadoutSlots.Count - 1)]
        public int inventorySlot = 0;

        [Header("New weapon defaults (Item Batch)")]
        [Tooltip("Viewmodel given to new weapons of this type that don't copy from another weapon.")]
        public WeaponViewmodelSO defaultViewmodel;
        [Tooltip("Shader preset given to new weapons of this type that don't copy from another weapon. Empty = original look.")]
        public WeaponShaderSO defaultShader;

        [Header("Perks")]
        [Tooltip("Default roll columns for weapons of this type. A weapon with its own columns uses those instead.")]
        public List<PerkColumn> perkColumns = new List<PerkColumn>();
    }
}