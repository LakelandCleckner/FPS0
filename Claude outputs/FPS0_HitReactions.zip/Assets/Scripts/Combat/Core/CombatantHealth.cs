using UnityEngine;
using Combat.Core;
using Combat.Stats;
using Combat.Spawning;

// Something that soaks damage before health (an enemy shield). Returns what passes through.
public interface IDamageAbsorber
{
    float Absorb(float damage, DamageTypeSO type);
}

// Health state + defensive layers for a combatant. Phase: defensive stats.
//
// Pooling: fires OnDeath instead of destroying, so a PooledEnemy can decide when/how
// the instance returns to its pool (immediately now; deferred for a death animation or
// a status-transfer read later). Implements IPoolable so a reused instance resets its
// health and clears IsDying -- neither of which happens on their own, since currentHealth
// is set in Start (once per instance) and IsDying is a one-way latch.
public class CombatantHealth : MonoBehaviour, IPoolable
{
    public enum MaxHealthChangeMode { ClampOnly, Proportional, Additive }

    [Header("Stats")]
    [SerializeField] private CombatantStats combatantStats;
    [SerializeField] private StatDefinitionSO maxHealthStat;
    [Tooltip("General defensive stats (damage_taken). Per-type resistance lives on " +
             "the DamageTypeSO.")]
    [SerializeField] private DefenseStatKeys defenseKeys;

    [Header("Max Health Changes")]
    [SerializeField] private MaxHealthChangeMode maxHealthChangeMode = MaxHealthChangeMode.ClampOnly;

    private float currentHealth;
    private bool started;

    private float cachedMax;
    private int cachedMaxVersion = int.MinValue;

    public bool IsDying { get; private set; }

    // Body part of the most recent damage, so death reactions can tell a precision kill.
    public BodyPart LastHitPart { get; private set; } = BodyPart.Torso;

    // Optional layer in front of health, e.g. an enemy shield.
    public IDamageAbsorber Absorber { get; set; }

    // Fired when this combatant dies (health hits 0). A PooledEnemy subscribes to
    // return the instance to its pool; anything else (score, loot, VFX) can too. Death
    // no longer destroys the object itself -- the handler decides its fate. If NOTHING
    // handles this, the object simply persists dying; PooledEnemy's fallback destroys
    // a non-pooled one.
    public event System.Action OnDeath;

    // (current, max). Fired on damage, heal, spawn and max-health changes.
    public event System.Action<float, float> HealthChanged;

    // A damaging hit that left this combatant alive, after its damage applied
    public event System.Action<HitReport> Damaged;

    // Damage the last TakeDamage removed from health (after the absorber)
    private float lastHealthDamage;

    private void NotifyHealth() => HealthChanged?.Invoke(currentHealth, cachedMax);

    public float MaxHealth { get { RefreshMax(); return cachedMax; } }
    public float CurrentHealth => currentHealth;

    // --- Body-part resistance (authored array; positional, tied to hitbox setup) ---
    [System.Serializable]
    public struct BodyPartResistance { public BodyPart part; public float multiplier; }
    [SerializeField] private BodyPartResistance[] bodyPartResistances;

    private StatContainer Container => combatantStats != null ? combatantStats.Container : null;

    private void Awake()
    {
        if (combatantStats == null)
            combatantStats = GetComponent<CombatantStats>();
    }

    private void Start()
    {
        RefreshMax();
        currentHealth = cachedMax;
        started = true;
        NotifyHealth();
    }

    // ---- IPoolable ----

    // Reused instance: refill to full and clear the dying latch. Without this a
    // respawned enemy keeps its last life's currentHealth (0 -- dead) and its latched
    // IsDying, i.e. it spawns dead. Start does NOT run on reuse, so this is the only
    // reset path.
    public void OnSpawn()
    {
        IsDying = false;
        LastHitPart = BodyPart.Torso;
        cachedMaxVersion = int.MinValue;   // force a fresh max resolve
        RefreshMax();
        currentHealth = cachedMax;
        started = true;                    // in case OnSpawn beats Start on first life
        NotifyHealth();
    }

    public void OnDespawn()
    {
        // Nothing needed pre-deactivate for health today. IsDying is cleared on the
        // next OnSpawn. Kept for the IPoolable contract.
    }

    private void RefreshMax()
    {
        var container = Container;
        if (container == null || maxHealthStat == null)
        {
            if (cachedMaxVersion == int.MinValue) { cachedMax = 1f; cachedMaxVersion = 0; }
            return;
        }

        int v = container.GetVersion(maxHealthStat);
        if (v == cachedMaxVersion) return;

        float newMax = Mathf.Max(1f, container.Resolve(maxHealthStat));
        float oldMax = cachedMax;

        cachedMax = newMax;
        cachedMaxVersion = v;

        if (!started) return;
        if (oldMax <= 0f) { currentHealth = Mathf.Min(currentHealth, newMax); NotifyHealth(); return; }
        if (Mathf.Approximately(oldMax, newMax)) return;

        switch (maxHealthChangeMode)
        {
            case MaxHealthChangeMode.Proportional:
                currentHealth = Mathf.Clamp((currentHealth / oldMax) * newMax, 0f, newMax);
                break;
            case MaxHealthChangeMode.Additive:
                currentHealth = Mathf.Clamp(currentHealth + (newMax - oldMax), 0f, newMax);
                break;
            case MaxHealthChangeMode.ClampOnly:
            default:
                currentHealth = Mathf.Clamp(currentHealth, 0f, newMax);
                break;
        }

        NotifyHealth();
    }

    private float GetTypeMultiplier(DamageTypeSO type)
    {
        var container = Container;
        if (type == null || type.resistanceStat == null || container == null) return 1f;
        float resist = container.Resolve(type.resistanceStat);
        return Mathf.Max(0f, 1f - resist);
    }

    private float GetBodyPartResistance(BodyPart part)
    {
        if (bodyPartResistances != null)
            foreach (var b in bodyPartResistances)
                if (b.part == part) return b.multiplier;
        return 1f;
    }

    private float GetVulnerabilityMultiplier()
    {
        var container = Container;
        if (defenseKeys == null || defenseKeys.damageTaken == null || container == null) return 1f;
        return Mathf.Max(0f, 1f + container.Resolve(defenseKeys.damageTaken));
    }

    public float GetDamageMultiplier(DamageTypeSO type, BodyPart bodyPart)
    {
        return GetTypeMultiplier(type)
             * GetBodyPartResistance(bodyPart)
             * GetVulnerabilityMultiplier();
    }

    public bool IsDebuffed
    {
        get
        {
            var container = Container;
            if (defenseKeys == null || defenseKeys.damageTaken == null || container == null) return false;
            return container.Resolve(defenseKeys.damageTaken) > 0f;
        }
    }

    public void TakeDamage(float damage, BodyPart partHit, DamageTypeSO type)
    {
        if (IsDying) return;
        LastHitPart = partHit;
        lastHealthDamage = 0f;
        if (Absorber != null)
        {
            damage = Absorber.Absorb(damage, type);
            if (damage <= 0f) return;
        }
        RefreshMax();
        lastHealthDamage = Mathf.Min(damage, currentHealth);
        currentHealth = Mathf.Clamp(currentHealth - damage, 0f, cachedMax);
        NotifyHealth();
        if (currentHealth == 0f)
        {
            IsDying = true;
            Die();
        }
    }

    // Dies now, skipping the absorber (self-detonation). Counts as a body kill, not a precision one.
    public void Kill()
    {
        if (IsDying) return;
        LastHitPart = BodyPart.Torso;
        currentHealth = 0f;
        NotifyHealth();
        IsDying = true;
        Die();
    }

    // Called by the damage effect right after its TakeDamage, so HealthDamage is that hit's
    public void ReportHit(HitReport report)
    {
        report.HealthDamage = lastHealthDamage;
        lastHealthDamage = 0f;
        if (IsDying) return;
        Damaged?.Invoke(report);
    }

    public void Heal(float amount)
    {
        if (IsDying) return;
        RefreshMax();
        currentHealth = Mathf.Clamp(currentHealth + amount, 0f, cachedMax);
        NotifyHealth();
    }

    // Death no longer destroys directly. It fires OnDeath; a PooledEnemy returns the
    // instance to its pool (or a fallback destroys a non-pooled one). This is what lets
    // the return be DEFERRED -- for a death animation, or so a status transfer can read
    // this corpse's still-alive status pools before anything resets or deactivates.
    private void Die()
    {
        OnDeath?.Invoke();
    }
}